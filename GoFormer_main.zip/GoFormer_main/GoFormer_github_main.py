import scipy.io
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import confusion_matrix


def get_device():
    return 'cuda' if torch.cuda.is_available() else 'cpu'
device = get_device()

def entropy_regularization(tensor):
    probabilities = F.softmax(tensor, dim=3)
    log_probabilities = torch.log(probabilities)
    entropy = torch.sum(-probabilities * log_probabilities, dim=3)
    regularization = -torch.sum(entropy)
    return regularization

class PoswiseFeedForwardNet(nn.Module):
    def __init__(self):
        super(PoswiseFeedForwardNet, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_ff, kernel_size=1)
        self.conv2 = nn.Conv1d(in_channels=d_ff, out_channels=d_model, kernel_size=1)
        self.layer_norm = nn.LayerNorm(d_model)

    def forward(self, inputs):
        residual = inputs 
        output = nn.ReLU()(self.conv1(inputs.transpose(1, 2)))
        output = self.conv2(output).transpose(1, 2)
        return self.layer_norm(output + residual)
    
class ScaledDotProductAttention(nn.Module):
    def __init__(self):
        super(ScaledDotProductAttention, self).__init__()
        
    def forward(self, Q, K, V):
        x1 = Q.unsqueeze(-1)  
        x2 = Q.unsqueeze(-2)  
        diff = x1 - x2  
        norm_square = torch.sum(diff **2, dim=-1)  
        attn = torch.exp(-norm_square / 1)
        context = torch.matmul(attn, V)
        return context, attn

class MultiHeadAttention(nn.Module):
    def __init__(self):
        super(MultiHeadAttention, self).__init__()
        self.W_Q = nn.Linear(d_model, d_k * n_heads)
        self.linear = nn.Linear(n_heads * d_v, d_model)
        self.layer_norm = nn.LayerNorm(d_model)

    def forward(self, Q, K, V):
        residual, batch_size = Q, Q.size(0)
        q_s = self.W_Q(Q).view(batch_size, -1, n_heads, d_k).transpose(1,2)
        k_s = self.W_Q(K).view(batch_size, -1, n_heads, d_k).transpose(1,2)
        v_s = self.W_Q(V).view(batch_size, -1, n_heads, d_v).transpose(1,2)
        context, attn = ScaledDotProductAttention()(q_s, k_s, v_s)
        context = context.transpose(1, 2).contiguous().view(batch_size, -1, n_heads * d_v)
        output = self.linear(context)
        return self.layer_norm(output + residual), attn    
      
class EncoderLayer(nn.Module):
    def __init__(self):
        super(EncoderLayer, self).__init__()
        self.enc_self_attn = MultiHeadAttention()
        self.pos_ffn = PoswiseFeedForwardNet()

    def forward(self, enc_inputs):   
        enc_outputs, attn = self.enc_self_attn(enc_inputs, enc_inputs, enc_inputs)
        enc_outputs = self.pos_ffn(enc_outputs)
        return enc_outputs, attn

class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        n_layers=2 
        self.abc=EncoderLayer()
        self.layers = nn.ModuleList([self.abc for _ in range(n_layers)])
        
    def forward(self, enc_inputs):      
        enc_outputs=enc_inputs
        enc_self_attns = []
        for layer in self.layers:
            enc_outputs, enc_self_attn = layer(enc_outputs)
            enc_self_attns.append(enc_self_attn) 
        return enc_outputs, enc_self_attns


class Goformer(nn.Module):
    def __init__(self):
        super(Goformer, self).__init__()
        self.encoder = Encoder()
        self.dense_1 =nn.Linear(13456,64)
        self.dense_2 =nn.Linear(64,32)
        self.dense_3 =nn.Linear(32,2)
        self.relu =nn.ReLU()
        self.dropout =nn.Dropout(p=0.5)

    def forward(self, enc_inputs):  
        enc_outputs, enc_self_attns = self.encoder(enc_inputs)
        cc=entropy_regularization(enc_self_attns[1])#1
        x = enc_outputs.view(enc_outputs.size(0), -1)
        x =self.dense_1(x)
        x = self.relu(x)
        x =self.dense_2(x)
        x = self.relu(x)
        x =self.dense_3(x)
        x=F.log_softmax(x, dim=1)
        return x,cc,enc_self_attns
    
def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels),preds


def calculate_metric(gt, pred):
    pred[pred > 0.5] = 1
    pred[pred < 1] = 0
    confusion = confusion_matrix(gt, pred)
    TP = confusion[1, 1]
    TN = confusion[0, 0]
    FP = confusion[0, 1]
    FN = confusion[1, 0]
    acc = (TP + TN) / float(TP + TN + FP + FN)
    sen = TP / float(TP + FN)
    spe = TN / float(TN + FP)
    bac =(sen+spe)/2
    ppv = TP/float(TP+FP)
    npv = TN/float(TN+FN)
    return acc,sen,spe,bac,ppv,npv


##load the dataset
class Fmri(object):                      
     def read_data(self):
         Dataset = scipy.io.loadmat('//media//nlp//data//pang//N2//NYU116.mat')
         bold =Dataset['AAL']
         A =bold[0]
         pc_l=[]
         for i in range(len(A)):
             pc= np.corrcoef(A[i].T)
             pc = np.nan_to_num(pc)
             pc_l.append(pc)
         X =np.array(pc_l)
         y = np.squeeze(Dataset['lab'])
         return X,y
  
Fulldataset=Fmri()
W=Fulldataset.read_data()
X=W[0]
y1=W[1]
y1[y1 == -1] = 0


##split the dataset
skf = StratifiedKFold(n_splits=10,shuffle=True,random_state=2)
fold = 1

for train_index, test_index in skf.split(X, y1):
    train_set = X[train_index,]
    train_label = y1[train_index,]
    test_set = X[test_index]
    test_label = y1[test_index] 
    filename = './train_data_'+str(fold)+'.npy'
    np.save(filename,train_set)
    filename = './train_label_'+str(fold)+'.npy'
    np.save(filename,train_label)
    filename = './test_data_'+str(fold)+'.npy'
    np.save(filename,test_set)
    filename = './test_label_'+str(fold)+'.npy'
    np.save(filename,test_label)     
    fold = fold + 1 
    print(fold)
    
src_len = 116
tgt_len = 116
d_model = 116
d_ff = 116
d_k = d_v = 116
n_heads = 1

accfold=[]
Labels=[]
aucv=[]
acctrue=[]    
sentrue=[]
spetrue=[]
bactrue=[]
ppvtrue=[]
npvtrue=[]



for fold in range(1,11):
    model = Goformer()
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(),
                        lr=0.001,weight_decay=0.00001)
    print('fold:',fold)
    train_data = np.load('./train_data_'+str(fold)+'.npy') 
    train_label = np.load('./train_label_'+str(fold)+'.npy') 
    test_data = np.load('./test_data_'+str(fold)+'.npy') 
    test_label = np.load('./test_label_'+str(fold)+'.npy')
    Labels.extend(test_label)
    train_data = torch.tensor(train_data).to(torch.float32).to(device)
    train_label = torch.tensor(train_label).long().to(device)
    test_data = torch.tensor(test_data).to(torch.float32).to(device)
    test_label = torch.tensor(test_label).long().to(device)

    
    for epoch in range(200):
        train_acc = 0.0
        train_loss = 0.0
        test_acc = 0.0
        test_loss = 0.0
        model.train().to(device)
        output,bb,tutu=model(train_data)
        batch_loss = criterion(F.log_softmax(output, dim=1), train_label.long())+0.0001*bb
        (PMXacc_train,hh)=accuracy(output,train_label)
        _, train_pred = torch.max(output, 1)  
        optimizer.zero_grad()
        batch_loss.backward()
        optimizer.step()
        train_acc += (train_pred.cpu() == train_label.cpu()).sum().item()
        train_loss += batch_loss.item()
        model.eval()
        with torch.no_grad():
            
            output,dd,tutu1 = model(test_data)
            batch_loss = criterion(output, test_label.long())+dd
            _, test_pred = torch.max(output, 1)
            (PMXacc_test,hh)=accuracy(output,test_label)
            test_acc += (
                    test_pred.cpu() == test_label.cpu()).sum().item()
            test_loss += batch_loss.item()
            test_acc = test_acc / len(test_label)
            train_acc = train_acc / len(train_label)
            train_loss=train_loss/len(train_label)
            test_loss=test_loss/len(test_label)
        
        print('Epoch: {:04d}'.format(epoch+1),
                      'loss_train: {:.4f}'.format(train_loss) ,
                      'acc_train: {:.4f}'.format(PMXacc_train) ,
                    'loss_val: {:.4f}'.format(test_loss),
                    'acc_val: {:.4f}'.format(PMXacc_test) )
        
        
        if epoch==199:            
            prediction=output[:,1]
            accfold.extend(test_pred)
        
            aucv.extend(prediction)
            Graphmatrix=tutu1[0].squeeze(1)
            test_label = test_label.cpu().numpy() if isinstance(
                test_label, torch.Tensor) else test_label
            test_pred = test_pred.cpu().numpy() if isinstance(
                test_pred, torch.Tensor) else test_pred
            print(test_label, test_pred)
            acc, sen, spe, bac, ppv, npv= calculate_metric(
                test_label, test_pred)
            acc, sen, spe,bac,ppv,npv=calculate_metric(test_label,test_pred)
            acctrue.append(acc)
            sentrue.append(sen)
            spetrue.append(spe)
            bactrue.append(bac)
            ppvtrue.append(ppv)
            npvtrue.append(npv)      

print(np.mean(acctrue))
print(np.mean(sentrue))
print(np.mean(spetrue))
print(np.mean(bactrue))
print(np.mean(ppvtrue))
print(np.mean(npvtrue))
